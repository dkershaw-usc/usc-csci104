int returns_42();

int returns_37();

int sum_arithmetic_sequence_recursive(int term_counts);

int sum_arithmetic_sequence_closed_form(int term_counts);

int sum_arithmetic_sequence_loop(int term_count);
